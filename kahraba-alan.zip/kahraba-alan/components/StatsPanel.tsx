'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { DAY_MS, dayKey, dayStart, fmtDayShort, fmtHours } from '@/lib/format';
import type { DailyStats, PeriodStats } from '@/lib/types';

type Tab = 'today' | 'week' | 'month';
const TABS: { id: Tab; label: string; days: number }[] = [
  { id: 'today', label: 'اليوم', days: 1 },
  { id: 'week', label: 'الأسبوع', days: 7 },
  { id: 'month', label: 'الشهر', days: 30 },
];

export default function StatsPanel({ neighborhoodId, version, now }: { neighborhoodId: string | null; version: number; now: number }) {
  const [tab, setTab] = useState<Tab>('today');
  const [stats, setStats] = useState<PeriodStats | null>(null);
  const [daily, setDaily] = useState<DailyStats[]>([]);
  const [loading, setLoading] = useState(false);
  const days = TABS.find((t) => t.id === tab)!.days;

  useEffect(() => {
    if (!neighborhoodId) return;
    let active = true;
    setLoading(true);
    const todayStart = dayStart(dayKey(Date.now()));
    const from = new Date(todayStart - (days - 1) * DAY_MS).toISOString();
    const to = new Date(todayStart + DAY_MS).toISOString();
    Promise.all([
      supabase.rpc('period_stats', { p_neighborhood: neighborhoodId, p_from: from, p_to: to }),
      supabase.rpc('daily_stats', { p_neighborhood: neighborhoodId, p_days: days }),
    ]).then(([p, d]) => {
      if (!active) return;
      setStats(((p.data as PeriodStats[] | null) ?? [])[0] ?? null);
      setDaily((d.data as DailyStats[] | null) ?? []);
      setLoading(false);
    });
    return () => { active = false; };
  }, [neighborhoodId, days, version]);

  const todayStart = dayStart(dayKey(now));
  const elapsed = Math.max(0, (Math.min(now, todayStart + DAY_MS) - (todayStart - (days - 1) * DAY_MS)) / 1000);
  const on = stats?.on_seconds ?? 0;
  const off = stats?.off_seconds ?? 0;
  const recorded = on + off;
  const availability = recorded > 0 ? Math.round((on / recorded) * 100) : null;
  const coverage = elapsed > 0 ? Math.min(100, Math.round((recorded / elapsed) * 100)) : 0;

  return (
    <section className="card p-5" aria-busy={loading}>
      <div className="flex items-center justify-between gap-3">
        <h2 className="font-display text-lg font-extrabold">إحصائيات الكهرباء</h2>
        <div role="tablist" aria-label="الفترة" className="flex rounded-xl bg-mist p-1">
          {TABS.map((t) => (
            <button key={t.id} role="tab" aria-selected={tab === t.id} onClick={() => setTab(t.id)}
              className={`rounded-lg px-3 py-1.5 text-sm font-bold ${tab === t.id ? 'bg-white shadow-sm' : 'text-muted'}`}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <dl className="mt-4 grid grid-cols-3 gap-2.5 text-center">
        <div className="rounded-xl bg-on-soft p-3">
          <dd className="font-display text-2xl font-extrabold text-on-deep">{fmtHours(on)}</dd>
          <dt className="text-xs text-on-deep">ساعة تشغيل</dt>
        </div>
        <div className="rounded-xl bg-off-soft p-3">
          <dd className="font-display text-2xl font-extrabold text-off-deep">{fmtHours(off)}</dd>
          <dt className="text-xs text-off-deep">ساعة انقطاع</dt>
        </div>
        <div className="rounded-xl bg-mist p-3">
          <dd className="font-display text-2xl font-extrabold">{stats?.cuts ?? 0}</dd>
          <dt className="text-xs text-muted">عدد القطعات</dt>
        </div>
      </dl>

      <p className="mt-3 text-sm text-muted">
        {availability === null
          ? 'لا توجد فترات مؤكدة في هذه المدة بعد.'
          : <>الكهرباء كانت شغالة <b className="text-ink">{availability}%</b> من الوقت المسجّل. المسجّل يغطي {coverage}% من المدة، والباقي بلا بيانات ولا يدخل في الحساب.</>}
      </p>

      {days > 1 && (
        <div className="mt-5">
          <h3 className="mb-2 text-sm font-bold">السجل اليومي</h3>
          <ul className="space-y-1.5">
            {[...daily].reverse().map((d) => {
              const isToday = d.day === dayKey(now);
              const span = isToday ? Math.max(1, (now - dayStart(d.day)) / 1000) : 86400;
              const wOn = Math.min(100, (d.on_seconds / span) * 100);
              const wOff = Math.min(100 - wOn, (d.off_seconds / span) * 100);
              const none = d.on_seconds + d.off_seconds === 0;
              return (
                <li key={d.day} className="grid grid-cols-[4.5rem_1fr_4.5rem] items-center gap-2 text-xs sm:grid-cols-[5.5rem_1fr_6rem]">
                  <span className="truncate text-muted">{fmtDayShort(d.day)}</span>
                  <div className="hatch flex h-3.5 overflow-hidden rounded-md border border-line" role="img"
                    aria-label={none ? 'لا بيانات' : `تشغيل ${fmtHours(d.on_seconds)} س، انقطاع ${fmtHours(d.off_seconds)} س`}>
                    <i className="bg-on" style={{ width: `${wOn}%` }} />
                    <i className="bg-off" style={{ width: `${wOff}%` }} />
                  </div>
                  <span className="text-end font-bold">{none ? '—' : `${fmtHours(d.on_seconds)} س · ${d.cuts} قطع`}</span>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </section>
  );
}
