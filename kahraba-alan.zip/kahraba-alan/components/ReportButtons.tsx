'use client';
import Link from 'next/link';
import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import type { PowerStatus } from '@/lib/types';
import { useAuth } from './AuthProvider';

interface Result { state: 'pending' | 'verified' | 'suspicious'; pending_count: number; threshold: number; kind: string }

export default function ReportButtons({ neighborhoodId, label }: { neighborhoodId: string | null; label: string }) {
  const { session, loading } = useAuth();
  const [busy, setBusy] = useState<PowerStatus | null>(null);
  const [msg, setMsg] = useState<{ tone: 'ok' | 'warn' | 'err'; text: string } | null>(null);

  async function send(status: PowerStatus) {
    if (!neighborhoodId || busy) return;
    setBusy(status); setMsg(null);
    const { data, error } = await supabase.rpc('submit_report', { p_neighborhood: neighborhoodId, p_status: status });
    setBusy(null);
    if (error) { setMsg({ tone: 'err', text: errorMessage(error) }); return; }
    const r = data as Result;
    if (r.state === 'verified') {
      setMsg({ tone: 'ok', text: r.kind === 'confirmation' ? 'شكراً! تم تسجيل تأكيدك للحالة الحالية.' : 'تم اعتماد الحالة الجديدة بعد تأكيد البلاغات.' });
    } else if (r.state === 'pending') {
      const left = Math.max(r.threshold - r.pending_count, 0);
      setMsg({ tone: 'warn', text: `تم استلام بلاغك وهو غير مؤكد بعد (${r.pending_count} من ${r.threshold}). يلزم ${left} ${left === 1 ? 'تأكيد' : 'تأكيدات'} إضافية من مستخدمين آخرين.` });
    } else {
      setMsg({ tone: 'warn', text: 'تم استلام بلاغك وسيُراجع قبل اعتماده.' });
    }
  }

  const disabled = !neighborhoodId || !!busy;
  const guest = !loading && !session;

  return (
    <section className="card p-5" aria-labelledby="report-h">
      <h2 id="report-h" className="font-display text-lg font-extrabold">بلّغ عن الكهرباء في {label}</h2>
      <p className="mt-0.5 text-sm text-muted">لا يتغيّر الوضع المعروض إلا بعد تأكيد عدة مستخدمين.</p>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <button type="button" disabled={disabled || guest} onClick={() => send('on')}
          className="flex min-h-[88px] flex-col items-center justify-center gap-1 rounded-2xl bg-on px-3 py-4 text-lg font-extrabold text-white shadow-sm transition active:scale-[0.98] hover:bg-on-deep disabled:opacity-50">
          <span aria-hidden className="text-2xl">🟢</span>
          {busy === 'on' ? 'جارٍ الإرسال…' : 'الكهرباء رجعت'}
        </button>
        <button type="button" disabled={disabled || guest} onClick={() => send('off')}
          className="flex min-h-[88px] flex-col items-center justify-center gap-1 rounded-2xl bg-off px-3 py-4 text-lg font-extrabold text-white shadow-sm transition active:scale-[0.98] hover:bg-off-deep disabled:opacity-50">
          <span aria-hidden className="text-2xl">🔴</span>
          {busy === 'off' ? 'جارٍ الإرسال…' : 'الكهرباء قطعت'}
        </button>
      </div>

      {guest && (
        <p className="mt-3 rounded-xl bg-mist p-3 text-sm">
          للإبلاغ تحتاج حساباً برقم هاتفك — هذا يمنع البلاغات المكررة والمزيّفة.{' '}
          <Link href="/login" className="font-bold underline">سجّل الدخول</Link>
        </p>
      )}
      {msg && (
        <p role="status" className={`mt-3 rounded-xl p-3 text-sm font-bold ${msg.tone === 'ok' ? 'bg-on-soft text-on-deep' : msg.tone === 'warn' ? 'bg-warn-soft text-warn' : 'bg-off-soft text-off-deep'}`}>
          {msg.text}
        </p>
      )}
    </section>
  );
}
