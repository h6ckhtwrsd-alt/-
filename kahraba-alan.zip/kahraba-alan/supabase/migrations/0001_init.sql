-- ============================================================
--  كهرباء الآن — Electricity Now
--  Supabase / PostgreSQL schema  (run once in the SQL Editor)
-- ============================================================
create extension if not exists pgcrypto;

-- ---------- settings ----------
create table if not exists app_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
insert into app_settings(key, value) values
  ('verify_threshold', '3'),          -- distinct users needed to verify a status change
  ('pending_window_minutes', '30'),   -- reports must agree within this window
  ('report_cooldown_minutes', '10'),  -- min gap between reports by one user in one neighborhood
  ('daily_report_cap', '30')          -- max reports per user per 24h
on conflict (key) do nothing;

create or replace function setting_int(p_key text, p_default int) returns int
language sql stable as $$
  select coalesce((select (value #>> '{}')::int from app_settings where key = p_key), p_default)
$$;

-- ---------- geography (generic: ready for all Sudanese states) ----------
create table if not exists states (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name_ar text not null,
  is_active boolean not null default true,
  sort_order int not null default 0
);
create table if not exists localities (
  id uuid primary key default gen_random_uuid(),
  state_id uuid not null references states(id) on delete cascade,
  slug text not null,
  name_ar text not null,
  is_active boolean not null default true,
  sort_order int not null default 0,
  unique (state_id, slug)
);
create table if not exists neighborhoods (
  id uuid primary key default gen_random_uuid(),
  locality_id uuid not null references localities(id) on delete cascade,
  name_ar text not null,
  verify_threshold int check (verify_threshold between 1 and 20), -- null = global default
  is_active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  unique (locality_id, name_ar)
);

-- ---------- profiles ----------
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text,
  display_name text,
  default_neighborhood_id uuid references neighborhoods(id) on delete set null,
  role text not null default 'citizen' check (role in ('citizen','moderator','admin')),
  is_banned boolean not null default false,
  trust_score int not null default 0,
  created_at timestamptz not null default now()
);

create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin' and not is_banned)
$$;
create or replace function is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role in ('admin','moderator') and not is_banned)
$$;

create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles(id, phone) values (new.id, new.phone) on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- users can never promote themselves (SQL editor / service role have auth.uid() = null and are allowed)
create or replace function protect_profile() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not is_admin() then
    new.role := old.role;
    new.is_banned := old.is_banned;
    new.trust_score := old.trust_score;
    new.phone := old.phone;
  end if;
  return new;
end $$;
drop trigger if exists protect_profile_trg on profiles;
create trigger protect_profile_trg before update on profiles
  for each row execute function protect_profile();

-- ---------- reports (full audit history — never deleted) ----------
create table if not exists reports (
  id uuid primary key default gen_random_uuid(),
  neighborhood_id uuid not null references neighborhoods(id),
  user_id uuid references profiles(id) on delete set null,
  status text not null check (status in ('on','off')),
  state text not null default 'pending' check (state in ('pending','verified','rejected','suspicious')),
  kind text not null default 'change' check (kind in ('change','confirmation')),
  created_at timestamptz not null default now(),
  reviewed_by uuid,
  reviewed_at timestamptz,
  review_note text
);
create index if not exists reports_nb_idx on reports (neighborhood_id, created_at desc);
create index if not exists reports_user_idx on reports (user_id, created_at desc);
create index if not exists reports_state_idx on reports (state, created_at desc);

-- ---------- verified status changes: the ONLY source for durations ----------
create table if not exists status_events (
  id uuid primary key default gen_random_uuid(),
  neighborhood_id uuid not null references neighborhoods(id) on delete cascade,
  status text not null check (status in ('on','off')),
  started_at timestamptz not null,
  source text not null default 'citizen' check (source in ('citizen','moderator','admin')),
  report_count int not null default 1,
  created_by uuid,
  created_at timestamptz not null default now(),
  unique (neighborhood_id, started_at)
);
create index if not exists status_events_idx on status_events (neighborhood_id, started_at desc);

-- ---------- live snapshot (what the app shows + subscribes to via Realtime) ----------
create table if not exists neighborhood_live (
  neighborhood_id uuid primary key references neighborhoods(id) on delete cascade,
  status text check (status in ('on','off')),      -- NULL = no verified data yet (never fabricated)
  since timestamptz,
  confirmations int not null default 0,
  last_report_at timestamptz,
  pending_status text check (pending_status in ('on','off')),
  pending_count int not null default 0,
  updated_at timestamptz not null default now()
);

create or replace function create_live_row() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into neighborhood_live(neighborhood_id) values (new.id) on conflict do nothing;
  return new;
end $$;
drop trigger if exists neighborhoods_live_trg on neighborhoods;
create trigger neighborhoods_live_trg after insert on neighborhoods
  for each row execute function create_live_row();

-- ---------- admin audit log ----------
create table if not exists audit_log (
  id bigint generated always as identity primary key,
  actor uuid,
  action text not null,
  entity text not null,
  entity_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function log_audit(p_action text, p_entity text, p_entity_id text, p_details jsonb)
returns void language sql security definer set search_path = public as $$
  insert into audit_log(actor, action, entity, entity_id, details)
  values (auth.uid(), p_action, p_entity, p_entity_id, coalesce(p_details, '{}'::jsonb))
$$;
revoke all on function log_audit(text,text,text,jsonb) from public, anon, authenticated;

-- ============================================================
--  Live snapshot refresh
-- ============================================================
create or replace function refresh_neighborhood_live(p_nid uuid) returns void
language plpgsql security definer set search_path = public as $$
declare
  v_status text; v_since timestamptz;
  v_conf int := 0; v_last timestamptz;
  v_pstatus text; v_pcount int := 0;
  v_window interval := make_interval(mins => setting_int('pending_window_minutes', 30));
begin
  select status, started_at into v_status, v_since
    from status_events where neighborhood_id = p_nid order by started_at desc limit 1;

  if v_status is not null then
    select count(distinct user_id) into v_conf from reports
      where neighborhood_id = p_nid and status = v_status
        and state = 'verified' and created_at >= v_since;
  end if;

  select max(created_at) into v_last from reports
    where neighborhood_id = p_nid and state in ('pending','verified');

  select status, count(distinct user_id) into v_pstatus, v_pcount from reports
    where neighborhood_id = p_nid and state = 'pending'
      and created_at >= now() - v_window
      and created_at > coalesce(v_since, '-infinity'::timestamptz)
      and (v_status is null or status <> v_status)
    group by status order by count(distinct user_id) desc limit 1;

  insert into neighborhood_live(neighborhood_id, status, since, confirmations, last_report_at,
                                pending_status, pending_count, updated_at)
  values (p_nid, v_status, v_since, coalesce(v_conf,0), v_last, v_pstatus, coalesce(v_pcount,0), now())
  on conflict (neighborhood_id) do update set
    status = excluded.status, since = excluded.since, confirmations = excluded.confirmations,
    last_report_at = excluded.last_report_at, pending_status = excluded.pending_status,
    pending_count = excluded.pending_count, updated_at = now();
end $$;
revoke all on function refresh_neighborhood_live(uuid) from public, anon, authenticated;

-- ============================================================
--  submit_report — the only way a citizen can write a report
--  Error codes (raised as exception text): AUTH_REQUIRED, BANNED, INVALID_STATUS,
--  INVALID_NEIGHBORHOOD, COOLDOWN, DAILY_CAP, DUPLICATE
-- ============================================================
create or replace function submit_report(p_neighborhood uuid, p_status text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_profile profiles;
  v_cooldown int := setting_int('report_cooldown_minutes', 10);
  v_cap int := setting_int('daily_report_cap', 30);
  v_window interval := make_interval(mins => setting_int('pending_window_minutes', 30));
  v_threshold int;
  v_cur_status text; v_cur_since timestamptz;
  v_last_status text; v_last_at timestamptz;
  v_recent int; v_hoods int;
  v_state text; v_kind text; v_report_id uuid;
  v_count int := 0; v_first timestamptz; v_event boolean := false;
  v_is_staff boolean;
begin
  if v_uid is null then raise exception 'AUTH_REQUIRED'; end if;
  if p_status not in ('on','off') then raise exception 'INVALID_STATUS'; end if;

  select * into v_profile from profiles where id = v_uid;
  if not found or v_profile.is_banned then raise exception 'BANNED'; end if;
  v_is_staff := v_profile.role in ('admin','moderator');

  select coalesce(n.verify_threshold, setting_int('verify_threshold', 3)) into v_threshold
    from neighborhoods n where n.id = p_neighborhood and n.is_active;
  if v_threshold is null then raise exception 'INVALID_NEIGHBORHOOD'; end if;

  perform pg_advisory_xact_lock(hashtext(p_neighborhood::text));

  -- anti-spam 1: cooldown per user per neighborhood
  if exists (select 1 from reports where user_id = v_uid and neighborhood_id = p_neighborhood
             and state <> 'rejected' and created_at > now() - make_interval(mins => v_cooldown)) then
    raise exception 'COOLDOWN';
  end if;
  -- anti-spam 2: daily cap
  if (select count(*) from reports where user_id = v_uid and created_at > now() - interval '24 hours') >= v_cap then
    raise exception 'DAILY_CAP';
  end if;

  select status, started_at into v_cur_status, v_cur_since
    from status_events where neighborhood_id = p_neighborhood order by started_at desc limit 1;

  -- anti-spam 3: duplicates (one vote per user per status period / pending window)
  select status, created_at into v_last_status, v_last_at from reports
    where user_id = v_uid and neighborhood_id = p_neighborhood and state <> 'rejected'
    order by created_at desc limit 1;
  if v_last_status = p_status then
    if v_cur_status is not null and p_status = v_cur_status and v_last_at >= v_cur_since then
      raise exception 'DUPLICATE';
    elsif (v_cur_status is null or p_status <> v_cur_status) and v_last_at > now() - v_window then
      raise exception 'DUPLICATE';
    end if;
  end if;

  -- anti-spam 4: suspicious behaviour (many reports / many neighborhoods within an hour)
  select count(*), count(distinct neighborhood_id) into v_recent, v_hoods
    from reports where user_id = v_uid and created_at > now() - interval '1 hour';

  v_kind := case when v_cur_status is not null and p_status = v_cur_status then 'confirmation' else 'change' end;

  if not v_is_staff and (v_hoods >= 3 or v_recent >= 6) then
    v_state := 'suspicious';
  elsif v_kind = 'confirmation' or v_is_staff then
    v_state := 'verified';
  else
    v_state := 'pending';
  end if;

  insert into reports(neighborhood_id, user_id, status, state, kind)
  values (p_neighborhood, v_uid, p_status, v_state, v_kind)
  returning id into v_report_id;

  if v_kind = 'change' and v_state <> 'suspicious' then
    if v_is_staff then
      insert into status_events(neighborhood_id, status, started_at, source, report_count, created_by)
      values (p_neighborhood, p_status, now(), 'moderator', 1, v_uid)
      on conflict do nothing;
      v_event := true; v_count := 1;
    else
      select count(distinct user_id), min(created_at) into v_count, v_first from reports
        where neighborhood_id = p_neighborhood and status = p_status and state = 'pending'
          and created_at >= now() - v_window
          and created_at > coalesce(v_cur_since, '-infinity'::timestamptz);

      if v_count >= v_threshold then
        insert into status_events(neighborhood_id, status, started_at, source, report_count)
        values (p_neighborhood, p_status, v_first, 'citizen', v_count)
        on conflict do nothing;

        with u as (
          update reports set state = 'verified'
           where neighborhood_id = p_neighborhood and status = p_status and state = 'pending'
             and created_at >= now() - v_window
             and created_at > coalesce(v_cur_since, '-infinity'::timestamptz)
          returning user_id
        )
        update profiles set trust_score = trust_score + 1 where id in (select user_id from u);
        v_event := true;
      end if;
    end if;
  end if;

  perform refresh_neighborhood_live(p_neighborhood);

  return jsonb_build_object(
    'report_id', v_report_id, 'state', case when v_event then 'verified' else v_state end,
    'kind', v_kind, 'event_created', v_event,
    'pending_count', v_count, 'threshold', v_threshold);
end $$;
revoke all on function submit_report(uuid, text) from public, anon;
grant execute on function submit_report(uuid, text) to authenticated;

-- ============================================================
--  Staff / admin actions (all audited)
-- ============================================================
create or replace function admin_review_report(p_report uuid, p_state text, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare r reports; v_cur_status text; v_cur_since timestamptz;
begin
  if not is_staff() then raise exception 'FORBIDDEN'; end if;
  if p_state not in ('pending','verified','rejected','suspicious') then raise exception 'INVALID_STATE'; end if;
  select * into r from reports where id = p_report;
  if not found then raise exception 'NOT_FOUND'; end if;

  update reports set state = p_state, review_note = p_note, reviewed_by = auth.uid(), reviewed_at = now()
   where id = p_report;

  if p_state = 'verified' and r.kind = 'change' then
    select status, started_at into v_cur_status, v_cur_since
      from status_events where neighborhood_id = r.neighborhood_id order by started_at desc limit 1;
    if (v_cur_status is null or v_cur_status <> r.status)
       and r.created_at > coalesce(v_cur_since, '-infinity'::timestamptz) then
      insert into status_events(neighborhood_id, status, started_at, source, report_count, created_by)
      values (r.neighborhood_id, r.status, r.created_at, 'moderator', 1, auth.uid())
      on conflict do nothing;
    end if;
  end if;

  perform log_audit('review_report', 'report', p_report::text,
    jsonb_build_object('from', r.state, 'to', p_state, 'note', p_note));
  perform refresh_neighborhood_live(r.neighborhood_id);
end $$;

create or replace function admin_set_status(p_neighborhood uuid, p_status text, p_at timestamptz default now()) returns void
language plpgsql security definer set search_path = public as $$
declare v_cur_status text; v_cur_since timestamptz;
begin
  if not is_staff() then raise exception 'FORBIDDEN'; end if;
  if p_status not in ('on','off') then raise exception 'INVALID_STATUS'; end if;
  if p_at > now() then raise exception 'INVALID_TIME'; end if;
  select status, started_at into v_cur_status, v_cur_since
    from status_events where neighborhood_id = p_neighborhood order by started_at desc limit 1;
  if v_cur_status = p_status then raise exception 'NO_CHANGE'; end if;
  if v_cur_since is not null and p_at <= v_cur_since then raise exception 'INVALID_TIME'; end if;
  insert into status_events(neighborhood_id, status, started_at, source, report_count, created_by)
  values (p_neighborhood, p_status, p_at, case when is_admin() then 'admin' else 'moderator' end, 0, auth.uid());
  perform log_audit('set_status', 'neighborhood', p_neighborhood::text,
    jsonb_build_object('status', p_status, 'at', p_at));
  perform refresh_neighborhood_live(p_neighborhood);
end $$;

create or replace function admin_delete_event(p_event uuid) returns void
language plpgsql security definer set search_path = public as $$
declare e status_events;
begin
  if not is_admin() then raise exception 'FORBIDDEN'; end if;
  select * into e from status_events where id = p_event;
  if not found then raise exception 'NOT_FOUND'; end if;
  delete from status_events where id = p_event;
  perform log_audit('delete_event', 'status_event', p_event::text, to_jsonb(e));
  perform refresh_neighborhood_live(e.neighborhood_id);
end $$;

-- ============================================================
--  Statistics — computed only from verified status_events.
--  Time before the first verified event is "unknown" and is NOT counted.
--  Sudan has no DST: Africa/Khartoum = UTC+2.
-- ============================================================
create or replace function period_stats(p_neighborhood uuid, p_from timestamptz, p_to timestamptz)
returns table (on_seconds bigint, off_seconds bigint, cuts int)
language sql stable security definer set search_path = public as $$
  with ev as (
    select status, started_at,
           coalesce(lead(started_at) over (order by started_at), now()) as ended_at
    from status_events where neighborhood_id = p_neighborhood
  ), c as (
    select status, greatest(started_at, p_from) as s, least(ended_at, p_to, now()) as e from ev
  )
  select
    coalesce(sum(extract(epoch from (e - s))) filter (where status = 'on'  and e > s), 0)::bigint,
    coalesce(sum(extract(epoch from (e - s))) filter (where status = 'off' and e > s), 0)::bigint,
    (select count(*)::int from status_events
      where neighborhood_id = p_neighborhood and status = 'off'
        and started_at >= p_from and started_at < p_to)
  from c
$$;

create or replace function daily_stats(p_neighborhood uuid, p_days int default 7)
returns table (day date, on_seconds bigint, off_seconds bigint, cuts int)
language sql stable security definer set search_path = public as $$
  select d.day, ps.on_seconds, ps.off_seconds, ps.cuts
  from (
    select ((now() at time zone 'Africa/Khartoum')::date - g.i) as day
    from generate_series(0, greatest(p_days, 1) - 1) as g(i)
  ) d,
  lateral period_stats(
    p_neighborhood,
    (d.day::timestamp at time zone 'Africa/Khartoum'),
    ((d.day + 1)::timestamp at time zone 'Africa/Khartoum')
  ) ps
  order by d.day
$$;

create or replace function region_stats(p_from timestamptz, p_to timestamptz)
returns table (neighborhood_id uuid, on_seconds bigint, off_seconds bigint, cuts int)
language plpgsql stable security definer set search_path = public as $$
begin
  if not is_staff() then raise exception 'FORBIDDEN'; end if;
  return query
    select n.id, ps.on_seconds, ps.off_seconds, ps.cuts
    from neighborhoods n, lateral period_stats(n.id, p_from, p_to) ps
    where n.is_active;
end $$;

-- ============================================================
--  Row Level Security
-- ============================================================
alter table app_settings      enable row level security;
alter table states            enable row level security;
alter table localities        enable row level security;
alter table neighborhoods     enable row level security;
alter table profiles          enable row level security;
alter table reports           enable row level security;
alter table status_events     enable row level security;
alter table neighborhood_live enable row level security;
alter table audit_log         enable row level security;

create policy settings_read  on app_settings for select using (true);
create policy settings_admin on app_settings for all using (is_admin()) with check (is_admin());

create policy states_read  on states for select using (true);
create policy states_admin on states for all using (is_admin()) with check (is_admin());
create policy loc_read     on localities for select using (true);
create policy loc_admin    on localities for all using (is_admin()) with check (is_admin());
create policy nb_read      on neighborhoods for select using (true);
create policy nb_admin     on neighborhoods for all using (is_admin()) with check (is_admin());

create policy profiles_self_read   on profiles for select using (id = auth.uid() or is_staff());
create policy profiles_self_update on profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy profiles_admin_all   on profiles for all using (is_admin()) with check (is_admin());

create policy reports_read on reports for select using (user_id = auth.uid() or is_staff());
-- no insert/update/delete policies: reports are written only through RPC functions

create policy events_read  on status_events for select using (true);
create policy live_read    on neighborhood_live for select using (true);
create policy audit_read   on audit_log for select using (is_admin());

-- ---------- Realtime ----------
do $$ begin
  alter publication supabase_realtime add table public.neighborhood_live;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.status_events;
exception when duplicate_object then null; end $$;
