'use client';
import { useLocations } from '@/components/LocationProvider';
import LocationPicker from '@/components/LocationPicker';
import StatusCard from '@/components/StatusCard';
import ReportButtons from '@/components/ReportButtons';
import StatsPanel from '@/components/StatsPanel';
import Timeline from '@/components/Timeline';
import { useEvents, useNeighborhoodLive, useNow } from '@/lib/hooks';

export default function Dashboard() {
  const { sel, setSel, neighborhoods, localities, defaultThreshold, ready, label } = useLocations();
  const nb = neighborhoods.find((n) => n.id === sel.neighborhoodId) ?? null;
  const { live, version, loading } = useNeighborhoodLive(sel.neighborhoodId);
  const { events } = useEvents(sel.neighborhoodId, 14, version);
  const now = useNow();
  const loc = localities.find((l) => l.id === sel.localityId);
  const place = nb ? `${loc?.name_ar ?? ''} — ${nb.name_ar}` : '';
  const threshold = nb?.verify_threshold ?? defaultThreshold;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-2xl font-extrabold sm:text-3xl">الكهرباء في منطقتك.. لحظة بلحظة</h1>
        <p className="mt-1 text-sm text-muted">اختر حيّك وتابع حالة الكهرباء كما يؤكدها جيرانك.</p>
      </div>

      <section className="card p-4" aria-label="اختيار الموقع"><LocationPicker value={sel} onChange={setSel} /></section>

      {!ready ? (
        <p className="card p-6 text-center text-muted">جارٍ تحميل المواقع…</p>
      ) : !nb ? (
        <p className="card p-6 text-center text-muted">لا توجد أحياء متاحة بعد. أضفها من لوحة الإدارة.</p>
      ) : (
        <div className="grid gap-5 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
          <div className="space-y-5">
            <StatusCard live={live} label={place || label(nb.id)} threshold={threshold} events={events} now={now} loading={loading} />
            <ReportButtons neighborhoodId={nb.id} label={nb.name_ar} />
          </div>
          <div className="space-y-5">
            <StatsPanel neighborhoodId={nb.id} version={version} now={now} />
            <Timeline events={events} now={now} />
          </div>
        </div>
      )}
    </div>
  );
}
