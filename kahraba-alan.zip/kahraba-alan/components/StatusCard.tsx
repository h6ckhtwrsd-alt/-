'use client';
import { dayKey, fmtDuration, fmtTime, timeAgo } from '@/lib/format';
import { buildPeriods } from '@/lib/periods';
import type { NeighborhoodLive, StatusEvent } from '@/lib/types';
import DayStrip, { StripLegend } from './DayStrip';

function Bolt({ off }: { off?: boolean }) {
  return (
    <svg viewBox="0 0 24 24" className="h-12 w-12" aria-hidden>
      <path d="M13 2 4.5 13.5H11L10 22l9-12h-6.5L13 2z" fill="currentColor" />
      {off && <path d="M3.5 3.5l17 17" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" fill="none" />}
    </svg>
  );
}

export default function StatusCard({
  live, label, threshold, events, now, loading,
}: {
  live: NeighborhoodLive | null; label: string; threshold: number;
  events: StatusEvent[]; now: number; loading: boolean;
}) {
  const status = live?.status ?? null;
  const tone =
    status === 'on' ? { text: 'الكهرباء شغالة', lamp: 'bg-on text-white animate-glow', frame: 'border-on/40', chip: 'bg-on-soft text-on-deep' }
    : status === 'off' ? { text: 'الكهرباء قاطعة', lamp: 'bg-off text-white', frame: 'border-off/40', chip: 'bg-off-soft text-off-deep' }
    : { text: 'لا توجد حالة مؤكدة بعد', lamp: 'hatch text-muted border border-line', frame: 'border-line', chip: 'bg-mist text-muted' };

  const since = live?.since ?? null;
  const pending = live && live.pending_status && live.pending_count > 0 ? live : null;
  const periods = buildPeriods(events, now);

  return (
    <section className={`card border-2 p-5 ${tone.frame}`} aria-live="polite" aria-busy={loading}>
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-base font-bold text-muted">{label}</h2>
        <span className={`chip ${tone.chip}`}>{status ? 'حالة مؤكدة' : 'بانتظار التأكيد'}</span>
      </div>

      <div className="mt-4 flex items-center gap-4">
        <div className={`grid h-24 w-24 shrink-0 place-items-center rounded-full ${tone.lamp}`}>
          {status ? <Bolt off={status === 'off'} /> : <span className="text-4xl" aria-hidden>؟</span>}
        </div>
        <div className="min-w-0">
          <p className={`font-display text-3xl font-extrabold leading-tight ${status === 'on' ? 'text-on-deep' : status === 'off' ? 'text-off-deep' : 'text-ink'}`}>
            {tone.text}
          </p>
          {since ? (
            <p className="mt-1 text-base text-muted">
              منذ <b className="text-ink">{fmtDuration((now - Date.parse(since)) / 1000)}</b>
              <span className="text-sm"> (من الساعة {fmtTime(since)})</span>
            </p>
          ) : (
            <p className="mt-1 text-sm text-muted">لم يؤكد أحد حالة هذا الحي بعد. بلّغ بما تراه الآن.</p>
          )}
        </div>
      </div>

      <dl className="mt-5 grid grid-cols-2 gap-3 text-sm">
        <div className="rounded-xl bg-mist p-3">
          <dt className="text-muted">آخر بلاغ</dt>
          <dd className="mt-0.5 font-bold">{timeAgo(live?.last_report_at ?? null, now)}</dd>
        </div>
        <div className="rounded-xl bg-mist p-3">
          <dt className="text-muted">أكّدوا الحالة</dt>
          <dd className="mt-0.5 font-bold">{status ? `${live?.confirmations ?? 0} مستخدم` : '—'}</dd>
        </div>
      </dl>

      {pending && (
        <p className="mt-3 rounded-xl bg-warn-soft p-3 text-sm text-warn">
          <b>بلاغات غير مؤكدة:</b> {pending.pending_count} {pending.pending_count === 1 ? 'مستخدم يبلّغ' : 'مستخدمين يبلّغون'} أن الكهرباء{' '}
          {pending.pending_status === 'on' ? 'رجعت' : 'قطعت'}. تُعتمد الحالة عند وصول {threshold} تأكيدات.
        </p>
      )}

      <div className="mt-5">
        <div className="mb-1.5 flex items-center justify-between">
          <h3 className="text-sm font-bold">اليوم</h3>
          <span className="text-xs text-muted">من 00:00 إلى 24:00</span>
        </div>
        <DayStrip periods={periods} day={dayKey(now)} now={now} />
        <div className="mt-2"><StripLegend /></div>
      </div>
    </section>
  );
}
