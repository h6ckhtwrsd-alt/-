'use client';
import { useEffect, useState } from 'react';
import { supabase } from './supabase';
import { DAY_MS, dayKey, dayStart } from './format';
import type { NeighborhoodLive, StatusEvent } from './types';

export function useNow(ms = 30_000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), ms);
    return () => clearInterval(t);
  }, [ms]);
  return now;
}

/** Live snapshot of one neighborhood, kept fresh with Supabase Realtime. `version` bumps on every refresh. */
export function useNeighborhoodLive(id: string | null) {
  const [live, setLive] = useState<NeighborhoodLive | null>(null);
  const [version, setVersion] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!id) { setLive(null); return; }
    let active = true;
    setLoading(true);
    const load = async () => {
      const { data } = await supabase.from('neighborhood_live').select('*').eq('neighborhood_id', id).maybeSingle();
      if (!active) return;
      setLive((data as NeighborhoodLive | null) ?? null);
      setLoading(false);
      setVersion((v) => v + 1);
    };
    load();
    const channel = supabase
      .channel(`live-${id}`)
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'neighborhood_live', filter: `neighborhood_id=eq.${id}` },
        () => { load(); })
      .subscribe();
    const onVisible = () => { if (document.visibilityState === 'visible') load(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      active = false;
      document.removeEventListener('visibilitychange', onVisible);
      supabase.removeChannel(channel);
    };
  }, [id]);

  return { live, version, loading };
}

/** Verified status events for the last `days` calendar days (+ the one before, so the first day is correct). */
export function useEvents(id: string | null, days: number, version: number) {
  const [events, setEvents] = useState<StatusEvent[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!id) { setEvents([]); return; }
    let active = true;
    setLoading(true);
    (async () => {
      const since = new Date(dayStart(dayKey(Date.now())) - (days - 1) * DAY_MS).toISOString();
      const [inWindow, before] = await Promise.all([
        supabase.from('status_events').select('*').eq('neighborhood_id', id)
          .gte('started_at', since).order('started_at', { ascending: true }).limit(1000),
        supabase.from('status_events').select('*').eq('neighborhood_id', id)
          .lt('started_at', since).order('started_at', { ascending: false }).limit(1),
      ]);
      if (!active) return;
      setEvents([...((before.data ?? []) as StatusEvent[]), ...((inWindow.data ?? []) as StatusEvent[])]);
      setLoading(false);
    })();
    return () => { active = false; };
  }, [id, days, version]);

  return { events, loading };
}
