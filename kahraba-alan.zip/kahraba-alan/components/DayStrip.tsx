'use client';
import { DAY_MS, dayKey, dayStart, fmtDuration } from '@/lib/format';
import { clipPeriods, type Period } from '@/lib/periods';

/**
 * The signature element: a 24-hour strip for one day.
 * Green = power on, red = power off, hatched = nothing verified/recorded.
 * Time runs from the right (00:00) to the left (24:00), following Arabic reading direction.
 */
export default function DayStrip({
  periods, day, now, ticks = true, height = 'h-7',
}: { periods: Period[]; day: string; now: number; ticks?: boolean; height?: string }) {
  const start = dayStart(day);
  const end = start + DAY_MS;
  const isToday = dayKey(now) === day;
  const segs = clipPeriods(periods, start, Math.min(end, now));

  const on = segs.filter((s) => s.status === 'on').reduce((a, s) => a + (s.end - s.start), 0) / 1000;
  const off = segs.filter((s) => s.status === 'off').reduce((a, s) => a + (s.end - s.start), 0) / 1000;
  const aria = segs.length
    ? `شريط اليوم: تشغيل ${fmtDuration(on)}، انقطاع ${fmtDuration(off)}`
    : 'شريط اليوم: لا توجد بيانات مسجّلة';

  const pct = (ms: number) => `${((ms - start) / DAY_MS) * 100}%`;

  return (
    <div>
      <div role="img" aria-label={aria} className={`hatch relative w-full overflow-hidden rounded-lg border border-line ${height}`}>
        {segs.map((s, i) => (
          <div key={i}
            className={s.status === 'on' ? 'absolute inset-y-0 bg-on' : 'absolute inset-y-0 bg-off'}
            style={{ insetInlineStart: pct(s.start), width: `${((s.end - s.start) / DAY_MS) * 100}%` }} />
        ))}
        {isToday && (
          <>
            <div className="absolute inset-y-0 bg-white/70" style={{ insetInlineEnd: 0, width: `${((end - now) / DAY_MS) * 100}%` }} />
            <div className="absolute inset-y-0 w-0.5 bg-ink" style={{ insetInlineStart: pct(now) }} />
          </>
        )}
      </div>
      {ticks && (
        <div className="relative mt-1 h-4 text-[10px] text-muted" aria-hidden>
          {[0, 6, 12, 18, 24].map((h) => (
            <span key={h} className="absolute -translate-x-1/2 rtl:translate-x-1/2"
              style={{ insetInlineStart: `${(h / 24) * 100}%` }}>
              {h === 24 ? '24' : String(h).padStart(2, '0')}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

export function StripLegend() {
  return (
    <ul className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted">
      <li className="flex items-center gap-1.5"><i className="h-2.5 w-2.5 rounded-sm bg-on" />شغالة</li>
      <li className="flex items-center gap-1.5"><i className="h-2.5 w-2.5 rounded-sm bg-off" />قاطعة</li>
      <li className="flex items-center gap-1.5"><i className="hatch h-2.5 w-2.5 rounded-sm border border-line" />لا توجد بيانات</li>
    </ul>
  );
}
