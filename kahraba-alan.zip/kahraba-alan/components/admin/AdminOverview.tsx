'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { DAY_MS, dayKey, dayStart, fmtHours } from '@/lib/format';
import { downloadCsv } from '@/lib/csv';
import { useLocations } from '../LocationProvider';

interface RS { neighborhood_id: string; on_seconds: number; off_seconds: number; cuts: number }
const RANGES = [{ id: 1, label: 'اليوم' }, { id: 7, label: '7 أيام' }, { id: 30, label: '30 يوماً' }];

export default function AdminOverview({ isAdmin }: { isAdmin: boolean }) {
  const { label } = useLocations();
  const [days, setDays] = useState(7);
  const [rows, setRows] = useState<RS[]>([]);
  const [counts, setCounts] = useState({ pending: 0, suspicious: 0, users: 0 });
  const [note, setNote] = useState('');

  useEffect(() => {
    const todayStart = dayStart(dayKey(Date.now()));
    supabase.rpc('region_stats', {
      p_from: new Date(todayStart - (days - 1) * DAY_MS).toISOString(),
      p_to: new Date(todayStart + DAY_MS).toISOString(),
    }).then(({ data }) => setRows((data ?? []) as RS[]));
  }, [days]);

  useEffect(() => {
    Promise.all([
      supabase.from('reports').select('id', { count: 'exact', head: true }).eq('state', 'pending'),
      supabase.from('reports').select('id', { count: 'exact', head: true }).eq('state', 'suspicious'),
      supabase.from('profiles').select('id', { count: 'exact', head: true }),
    ]).then(([p, s, u]) => setCounts({ pending: p.count ?? 0, suspicious: s.count ?? 0, users: u.count ?? 0 }));
  }, []);

  async function exportTable(kind: 'reports' | 'events' | 'users' | 'audit') {
    setNote('');
    let rowsOut: Record<string, unknown>[] = [];
    if (kind === 'reports') {
      const { data } = await supabase.from('reports').select('*, profiles(phone)').order('created_at', { ascending: false }).limit(10000);
      rowsOut = ((data ?? []) as any[]).map((r) => ({
        id: r.id, الحي: label(r.neighborhood_id), الحالة: r.status === 'on' ? 'رجعت' : 'قطعت', الوضع: r.state,
        النوع: r.kind, الهاتف: r.profiles?.phone ?? '', الوقت: r.created_at, ملاحظة_المراجعة: r.review_note ?? '',
      }));
    } else if (kind === 'events') {
      const { data } = await supabase.from('status_events').select('*').order('started_at', { ascending: false }).limit(20000);
      rowsOut = ((data ?? []) as any[]).map((r) => ({
        id: r.id, الحي: label(r.neighborhood_id), الحالة: r.status === 'on' ? 'شغالة' : 'قاطعة', بداية_الفترة: r.started_at,
        المصدر: r.source, عدد_التأكيدات: r.report_count,
      }));
    } else if (kind === 'users') {
      const { data } = await supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(20000);
      rowsOut = ((data ?? []) as any[]).map((r) => ({
        id: r.id, الهاتف: r.phone ?? '', الاسم: r.display_name ?? '', الدور: r.role, محظور: r.is_banned ? 'نعم' : 'لا',
        الموثوقية: r.trust_score, تاريخ_الانضمام: r.created_at,
      }));
    } else {
      const { data } = await supabase.from('audit_log').select('*').order('created_at', { ascending: false }).limit(20000);
      rowsOut = ((data ?? []) as any[]).map((r) => ({ id: r.id, الإجراء: r.action, الكيان: r.entity, معرّف_الكيان: r.entity_id ?? '', تفاصيل: JSON.stringify(r.details), الوقت: r.created_at }));
    }
    if (!downloadCsv(`kahraba-alan-${kind}-${dayKey(Date.now())}.csv`, rowsOut)) setNote('لا توجد بيانات للتصدير.');
  }

  return (
    <div className="space-y-5">
      <dl className="grid grid-cols-3 gap-2.5 text-center">
        <div className="rounded-xl bg-warn-soft p-3"><dd className="font-display text-2xl font-extrabold text-warn">{counts.pending}</dd><dt className="text-xs text-warn">بلاغات قيد التأكيد</dt></div>
        <div className="rounded-xl bg-off-soft p-3"><dd className="font-display text-2xl font-extrabold text-off-deep">{counts.suspicious}</dd><dt className="text-xs text-off-deep">بلاغات مشبوهة</dt></div>
        <div className="rounded-xl bg-mist p-3"><dd className="font-display text-2xl font-extrabold">{counts.users}</dd><dt className="text-xs text-muted">مستخدمون</dt></div>
      </dl>

      <div>
        <div className="mb-2 flex items-center justify-between gap-2">
          <h3 className="font-display text-base font-extrabold">إحصائيات الأحياء</h3>
          <div className="flex rounded-xl bg-mist p-1">
            {RANGES.map((r) => (
              <button key={r.id} onClick={() => setDays(r.id)} className={`rounded-lg px-2.5 py-1 text-xs font-bold ${days === r.id ? 'bg-white shadow-sm' : 'text-muted'}`}>{r.label}</button>
            ))}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[420px] text-sm">
            <thead><tr className="text-start text-xs text-muted">
              <th className="py-2 text-start font-bold">الحي</th><th className="text-start font-bold">تشغيل (س)</th>
              <th className="text-start font-bold">انقطاع (س)</th><th className="text-start font-bold">قطعات</th>
            </tr></thead>
            <tbody className="divide-y divide-line">
              {rows.map((r) => (
                <tr key={r.neighborhood_id}>
                  <td className="py-2 font-bold">{label(r.neighborhood_id)}</td>
                  <td className="text-on-deep">{fmtHours(r.on_seconds)}</td>
                  <td className="text-off-deep">{fmtHours(r.off_seconds)}</td>
                  <td>{r.cuts}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div>
        <h3 className="mb-2 font-display text-base font-extrabold">تصدير التقارير (CSV)</h3>
        <div className="flex flex-wrap gap-2">
          <button className="btn-light" onClick={() => exportTable('reports')}>البلاغات</button>
          <button className="btn-light" onClick={() => exportTable('events')}>سجل الحالة المؤكد</button>
          {isAdmin && <button className="btn-light" onClick={() => exportTable('users')}>المستخدمون</button>}
          {isAdmin && <button className="btn-light" onClick={() => exportTable('audit')}>سجل التدقيق</button>}
        </div>
        {note && <p className="mt-2 text-sm text-muted">{note}</p>}
      </div>
    </div>
  );
}
