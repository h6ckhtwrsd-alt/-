export type PowerStatus = 'on' | 'off';
export type Role = 'citizen' | 'moderator' | 'admin';
export type ReportState = 'pending' | 'verified' | 'rejected' | 'suspicious';

export interface State { id: string; slug: string; name_ar: string; is_active: boolean; sort_order: number }
export interface Locality { id: string; state_id: string; slug: string; name_ar: string; is_active: boolean; sort_order: number }
export interface Neighborhood {
  id: string; locality_id: string; name_ar: string;
  verify_threshold: number | null; is_active: boolean; sort_order: number;
}
export interface NeighborhoodLive {
  neighborhood_id: string;
  status: PowerStatus | null;
  since: string | null;
  confirmations: number;
  last_report_at: string | null;
  pending_status: PowerStatus | null;
  pending_count: number;
  updated_at: string;
}
export interface StatusEvent {
  id: string; neighborhood_id: string; status: PowerStatus; started_at: string;
  source: 'citizen' | 'moderator' | 'admin'; report_count: number;
}
export interface Report {
  id: string; neighborhood_id: string; user_id: string | null; status: PowerStatus;
  state: ReportState; kind: 'change' | 'confirmation'; created_at: string;
  reviewed_at: string | null; review_note: string | null;
}
export interface Profile {
  id: string; phone: string | null; display_name: string | null;
  default_neighborhood_id: string | null; role: Role; is_banned: boolean;
  trust_score: number; created_at: string;
}
export interface PeriodStats { on_seconds: number; off_seconds: number; cuts: number }
export interface DailyStats extends PeriodStats { day: string }
export interface Sel { stateId: string | null; localityId: string | null; neighborhoodId: string | null }
