'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { FormEvent, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import { fmtDateTime, fmtPhone } from '@/lib/format';
import type { Report, ReportState, Sel } from '@/lib/types';
import { useAuth } from '@/components/AuthProvider';
import { useLocations } from '@/components/LocationProvider';
import LocationPicker from '@/components/LocationPicker';

const STATE_LABEL: Record<ReportState, { t: string; c: string }> = {
  verified: { t: 'مؤكد', c: 'bg-on-soft text-on-deep' },
  pending: { t: 'قيد التأكيد', c: 'bg-warn-soft text-warn' },
  suspicious: { t: 'قيد المراجعة', c: 'bg-warn-soft text-warn' },
  rejected: { t: 'مرفوض', c: 'bg-off-soft text-off-deep' },
};

export default function ProfilePage() {
  const router = useRouter();
  const { session, profile, loading, refreshProfile, signOut } = useAuth();
  const { sel: globalSel, setSel, neighborhoods, pick, label, ready } = useLocations();
  const [name, setName] = useState('');
  const [choice, setChoice] = useState<Sel>({ stateId: null, localityId: null, neighborhoodId: null });
  const [reports, setReports] = useState<Report[]>([]);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (!loading && !session) router.replace('/login'); }, [loading, session, router]);

  useEffect(() => {
    if (!profile || !ready) return;
    setName(profile.display_name ?? '');
    const target = profile.default_neighborhood_id && neighborhoods.some((n) => n.id === profile.default_neighborhood_id)
      ? pick('neighborhood', profile.default_neighborhood_id, globalSel) : globalSel;
    setChoice(target);
  }, [profile, ready]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!profile) return;
    supabase.from('reports').select('*').eq('user_id', profile.id).order('created_at', { ascending: false }).limit(30)
      .then(({ data }) => setReports((data ?? []) as Report[]));
  }, [profile]);

  async function save(e: FormEvent) {
    e.preventDefault();
    if (!profile) return;
    setBusy(true); setMsg(null);
    const { error } = await supabase.from('profiles')
      .update({ display_name: name.trim() || null, default_neighborhood_id: choice.neighborhoodId })
      .eq('id', profile.id);
    setBusy(false);
    if (error) { setMsg({ ok: false, text: errorMessage(error) }); return; }
    if (choice.neighborhoodId) setSel(choice);
    await refreshProfile();
    setMsg({ ok: true, text: 'تم حفظ التغييرات.' });
  }

  if (loading || !profile) return <p className="text-center text-muted">جارٍ التحميل…</p>;

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <h1 className="font-display text-2xl font-extrabold">حسابي</h1>

      <form onSubmit={save} className="card space-y-4 p-5">
        <div>
          <span className="mb-1 block text-sm font-bold text-muted">رقم الهاتف</span>
          <p dir="ltr" className="text-start font-bold">{fmtPhone(profile.phone)}</p>
        </div>
        <div>
          <label htmlFor="dn" className="mb-1 block text-sm font-bold text-muted">الاسم (اختياري)</label>
          <input id="dn" className="input" maxLength={40} value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <p className="mb-2 text-sm font-bold text-muted">الحي الافتراضي — يفتح التطبيق عليه مباشرة</p>
          <LocationPicker value={choice} onChange={setChoice} />
        </div>
        {msg && <p role="status" className={`text-sm font-bold ${msg.ok ? 'text-on-deep' : 'text-off-deep'}`}>{msg.text}</p>}
        <div className="flex flex-wrap gap-2">
          <button className="btn-dark" disabled={busy}>{busy ? 'جارٍ الحفظ…' : 'حفظ'}</button>
          <button type="button" className="btn-light" onClick={async () => { await signOut(); router.replace('/'); }}>تسجيل الخروج</button>
          {(profile.role === 'admin' || profile.role === 'moderator') && <Link href="/admin" className="btn-light">لوحة الإدارة</Link>}
        </div>
      </form>

      <section className="card p-5">
        <h2 className="font-display text-lg font-extrabold">بلاغاتي</h2>
        {reports.length === 0 ? (
          <p className="mt-2 text-sm text-muted">لم ترسل بلاغات بعد.</p>
        ) : (
          <ul className="mt-3 divide-y divide-line">
            {reports.map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
                <span className="min-w-0">
                  <b className={r.status === 'on' ? 'text-on-deep' : 'text-off-deep'}>{r.status === 'on' ? 'الكهرباء رجعت' : 'الكهرباء قطعت'}</b>
                  <span className="block truncate text-xs text-muted">{label(r.neighborhood_id)} · {fmtDateTime(r.created_at)}</span>
                </span>
                <span className={`chip shrink-0 ${STATE_LABEL[r.state].c}`}>{STATE_LABEL[r.state].t}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
