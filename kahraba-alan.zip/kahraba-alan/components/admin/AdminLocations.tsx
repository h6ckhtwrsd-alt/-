'use client';
import { FormEvent, useCallback, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import type { Locality, Neighborhood, State } from '@/lib/types';
import { useLocations } from '../LocationProvider';

export default function AdminLocations() {
  const { reload } = useLocations();
  const [states, setStates] = useState<State[]>([]);
  const [locs, setLocs] = useState<Locality[]>([]);
  const [nbs, setNbs] = useState<Neighborhood[]>([]);
  const [err, setErr] = useState('');
  const [stateName, setStateName] = useState('');
  const [locName, setLocName] = useState(''); const [locState, setLocState] = useState('');
  const [nbName, setNbName] = useState(''); const [nbLoc, setNbLoc] = useState(''); const [nbThr, setNbThr] = useState('');
  const [filterLoc, setFilterLoc] = useState('');

  const load = useCallback(async () => {
    const [s, l, n] = await Promise.all([
      supabase.from('states').select('*').order('sort_order'),
      supabase.from('localities').select('*').order('sort_order'),
      supabase.from('neighborhoods').select('*').order('sort_order').order('name_ar'),
    ]);
    setStates((s.data ?? []) as State[]); setLocs((l.data ?? []) as Locality[]); setNbs((n.data ?? []) as Neighborhood[]);
  }, []);
  useEffect(() => { load(); }, [load]);

  async function run(p: PromiseLike<{ error: { message?: string } | null }>) {
    setErr('');
    const { error } = await p;
    if (error) { setErr(errorMessage(error)); return false; }
    await load(); await reload(); return true;
  }
  const uid = () => `x${Date.now().toString(36)}`;

  async function addState(e: FormEvent) {
    e.preventDefault(); if (!stateName.trim()) return;
    if (await run(supabase.from('states').insert({ slug: uid(), name_ar: stateName.trim(), sort_order: states.length + 1 }))) setStateName('');
  }
  async function addLoc(e: FormEvent) {
    e.preventDefault(); if (!locName.trim() || !locState) return;
    if (await run(supabase.from('localities').insert({ state_id: locState, slug: uid(), name_ar: locName.trim(), sort_order: locs.length + 1 }))) setLocName('');
  }
  async function addNb(e: FormEvent) {
    e.preventDefault(); if (!nbName.trim() || !nbLoc) return;
    const thr = nbThr ? Number(nbThr) : null;
    if (await run(supabase.from('neighborhoods').insert({ locality_id: nbLoc, name_ar: nbName.trim(), verify_threshold: thr, sort_order: nbs.length + 1 }))) { setNbName(''); setNbThr(''); }
  }

  const list = nbs.filter((n) => !filterLoc || n.locality_id === filterLoc);

  return (
    <div className="space-y-6">
      {err && <p role="alert" className="text-sm font-bold text-off-deep">{err}</p>}

      <div className="grid gap-4 lg:grid-cols-3">
        <form onSubmit={addState} className="space-y-2 rounded-xl bg-mist p-3">
          <h3 className="text-sm font-extrabold">إضافة ولاية</h3>
          <input className="input" placeholder="اسم الولاية" value={stateName} onChange={(e) => setStateName(e.target.value)} />
          <button className="btn-dark w-full">إضافة</button>
        </form>
        <form onSubmit={addLoc} className="space-y-2 rounded-xl bg-mist p-3">
          <h3 className="text-sm font-extrabold">إضافة مدينة / محلية</h3>
          <select className="field" aria-label="الولاية" value={locState} onChange={(e) => setLocState(e.target.value)}>
            <option value="">اختر الولاية</option>{states.map((s) => <option key={s.id} value={s.id}>{s.name_ar}</option>)}
          </select>
          <input className="input" placeholder="اسم المدينة" value={locName} onChange={(e) => setLocName(e.target.value)} />
          <button className="btn-dark w-full">إضافة</button>
        </form>
        <form onSubmit={addNb} className="space-y-2 rounded-xl bg-mist p-3">
          <h3 className="text-sm font-extrabold">إضافة حي</h3>
          <select className="field" aria-label="المدينة" value={nbLoc} onChange={(e) => setNbLoc(e.target.value)}>
            <option value="">اختر المدينة</option>{locs.map((l) => <option key={l.id} value={l.id}>{l.name_ar}</option>)}
          </select>
          <input className="input" placeholder="اسم الحي" value={nbName} onChange={(e) => setNbName(e.target.value)} />
          <input className="input" inputMode="numeric" placeholder="عدد التأكيدات المطلوب (اختياري)" value={nbThr} onChange={(e) => setNbThr(e.target.value.replace(/\D/g, ''))} />
          <button className="btn-dark w-full">إضافة</button>
        </form>
      </div>

      <div>
        <div className="mb-2 flex items-center justify-between gap-3">
          <h3 className="font-display text-base font-extrabold">الأحياء ({list.length})</h3>
          <select className="field !w-auto" aria-label="تصفية بالمدينة" value={filterLoc} onChange={(e) => setFilterLoc(e.target.value)}>
            <option value="">كل المدن</option>{locs.map((l) => <option key={l.id} value={l.id}>{l.name_ar}</option>)}
          </select>
        </div>
        <ul className="divide-y divide-line">
          {list.map((n) => (
            <li key={n.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5 text-sm">
              <span className={n.is_active ? 'font-bold' : 'font-bold text-muted line-through'}>
                {locs.find((l) => l.id === n.locality_id)?.name_ar} — {n.name_ar}
              </span>
              <span className="flex items-center gap-2">
                <label className="flex items-center gap-1 text-xs text-muted">
                  تأكيدات
                  <input className="w-14 rounded-lg border border-line px-2 py-1 text-center text-ink" inputMode="numeric" placeholder="افتراضي"
                    defaultValue={n.verify_threshold ?? ''}
                    onBlur={(e) => {
                      const v = e.target.value ? Number(e.target.value) : null;
                      if (v !== n.verify_threshold) run(supabase.from('neighborhoods').update({ verify_threshold: v }).eq('id', n.id));
                    }} />
                </label>
                <button className="btn-light !min-h-[36px] !px-3 text-sm"
                  onClick={() => run(supabase.from('neighborhoods').update({ is_active: !n.is_active }).eq('id', n.id))}>
                  {n.is_active ? 'إيقاف' : 'تفعيل'}
                </button>
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
