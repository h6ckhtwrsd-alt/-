'use client';
import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import { fmtDateTime, fmtPhone } from '@/lib/format';
import type { Profile, Role } from '@/lib/types';
import { useAuth } from '../AuthProvider';

export default function AdminUsers() {
  const { profile: me } = useAuth();
  const [rows, setRows] = useState<Profile[]>([]);
  const [q, setQ] = useState('');
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    const { data } = await supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(300);
    setRows((data ?? []) as Profile[]);
  }, []);
  useEffect(() => { load(); }, [load]);

  async function update(id: string, patch: Partial<Pick<Profile, 'role' | 'is_banned'>>) {
    setErr('');
    const { error } = await supabase.from('profiles').update(patch).eq('id', id);
    if (error) setErr(errorMessage(error)); else load();
  }

  const shown = rows.filter((r) => !q || (r.phone ?? '').includes(q.replace(/^\+/, '')) || (r.display_name ?? '').includes(q));

  return (
    <div>
      <input className="input" placeholder="بحث برقم الهاتف أو الاسم" value={q} onChange={(e) => setQ(e.target.value)} dir="ltr" />
      {err && <p role="alert" className="mt-3 text-sm font-bold text-off-deep">{err}</p>}
      <ul className="mt-3 divide-y divide-line">
        {shown.map((u) => (
          <li key={u.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
            <span className="min-w-0">
              <b dir="ltr" className="block text-start">{fmtPhone(u.phone)}</b>
              <span className="text-xs text-muted">{u.display_name || 'بدون اسم'} · انضم {fmtDateTime(u.created_at)} · موثوقية {u.trust_score}</span>
            </span>
            <span className="flex items-center gap-2">
              <select className="field !w-auto !py-1.5 text-sm" aria-label="الدور" value={u.role} disabled={u.id === me?.id}
                onChange={(e) => update(u.id, { role: e.target.value as Role })}>
                <option value="citizen">مواطن</option><option value="moderator">مشرف</option><option value="admin">مدير</option>
              </select>
              <button disabled={u.id === me?.id} onClick={() => update(u.id, { is_banned: !u.is_banned })}
                className={`btn-light !min-h-[36px] !px-3 text-sm ${u.is_banned ? '!border-off !text-off-deep' : ''}`}>
                {u.is_banned ? 'رفع الحظر' : 'حظر'}
              </button>
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
