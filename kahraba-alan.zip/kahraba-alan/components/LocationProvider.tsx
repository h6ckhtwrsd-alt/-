'use client';
import { createContext, ReactNode, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Locality, Neighborhood, Sel, State } from '@/lib/types';
import { useAuth } from './AuthProvider';

const EMPTY: Sel = { stateId: null, localityId: null, neighborhoodId: null };
const KEY = 'ka:sel';

interface LocCtx {
  ready: boolean;
  states: State[];
  localities: Locality[];
  neighborhoods: Neighborhood[];
  defaultThreshold: number;
  sel: Sel;
  setSel: (s: Sel) => void;
  pick: (changed: 'state' | 'locality' | 'neighborhood', value: string, cur: Sel) => Sel;
  selectNeighborhood: (id: string) => void;
  label: (neighborhoodId: string) => string;
  reload: () => Promise<void>;
}

const Ctx = createContext<LocCtx | null>(null);
export function useLocations(): LocCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error('useLocations must be used inside LocationProvider');
  return c;
}

export default function LocationProvider({ children }: { children: ReactNode }) {
  const { profile } = useAuth();
  const [states, setStates] = useState<State[]>([]);
  const [localities, setLocalities] = useState<Locality[]>([]);
  const [neighborhoods, setNeighborhoods] = useState<Neighborhood[]>([]);
  const [defaultThreshold, setDefaultThreshold] = useState(3);
  const [ready, setReady] = useState(false);
  const [sel, setSelState] = useState<Sel>(EMPTY);
  const initialized = useRef(false);
  const hasStored = useRef(false);
  const appliedDefault = useRef(false);

  const reload = useCallback(async () => {
    const [s, l, n, cfg] = await Promise.all([
      supabase.from('states').select('*').eq('is_active', true).order('sort_order'),
      supabase.from('localities').select('*').eq('is_active', true).order('sort_order'),
      supabase.from('neighborhoods').select('*').eq('is_active', true).order('sort_order').order('name_ar'),
      supabase.from('app_settings').select('value').eq('key', 'verify_threshold').maybeSingle(),
    ]);
    setStates((s.data ?? []) as State[]);
    setLocalities((l.data ?? []) as Locality[]);
    setNeighborhoods((n.data ?? []) as Neighborhood[]);
    const t = Number((cfg.data as { value: unknown } | null)?.value);
    if (Number.isFinite(t) && t > 0) setDefaultThreshold(t);
    setReady(true);
  }, []);

  useEffect(() => { reload(); }, [reload]);

  const pick = useCallback((changed: 'state' | 'locality' | 'neighborhood', value: string, cur: Sel): Sel => {
    if (changed === 'neighborhood') {
      const nb = neighborhoods.find((x) => x.id === value);
      const loc = localities.find((x) => x.id === nb?.locality_id);
      return { stateId: loc?.state_id ?? cur.stateId, localityId: loc?.id ?? cur.localityId, neighborhoodId: value };
    }
    if (changed === 'locality') {
      const loc = localities.find((x) => x.id === value);
      const nb = neighborhoods.find((x) => x.locality_id === value);
      return { stateId: loc?.state_id ?? cur.stateId, localityId: value, neighborhoodId: nb?.id ?? null };
    }
    const loc = localities.find((x) => x.state_id === value);
    const nb = loc ? neighborhoods.find((x) => x.locality_id === loc.id) : undefined;
    return { stateId: value, localityId: loc?.id ?? null, neighborhoodId: nb?.id ?? null };
  }, [localities, neighborhoods]);

  const setSel = useCallback((s: Sel) => {
    setSelState(s);
    hasStored.current = true;
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* private mode */ }
  }, []);

  const selectNeighborhood = useCallback((id: string) => setSel(pick('neighborhood', id, EMPTY)), [pick, setSel]);

  const profileDefault = profile?.default_neighborhood_id ?? null;
  useEffect(() => {
    if (!ready) return;
    if (!initialized.current) {
      initialized.current = true;
      let stored: Sel | null = null;
      try { stored = JSON.parse(localStorage.getItem(KEY) || 'null') as Sel | null; } catch { stored = null; }
      if (stored?.neighborhoodId && neighborhoods.some((n) => n.id === stored!.neighborhoodId)) {
        hasStored.current = true;
        setSelState(stored);
      } else if (localities[0]) {
        setSelState(pick('locality', localities[0].id, EMPTY));
      }
    }
    if (profileDefault && !hasStored.current && !appliedDefault.current
        && neighborhoods.some((n) => n.id === profileDefault)) {
      appliedDefault.current = true;
      setSelState(pick('neighborhood', profileDefault, EMPTY));
    }
  }, [ready, profileDefault, neighborhoods, localities, pick]);

  const label = useCallback((id: string) => {
    const nb = neighborhoods.find((n) => n.id === id);
    const loc = localities.find((l) => l.id === nb?.locality_id);
    return nb ? `${loc?.name_ar ?? ''} — ${nb.name_ar}` : '—';
  }, [neighborhoods, localities]);

  return (
    <Ctx.Provider value={{ ready, states, localities, neighborhoods, defaultThreshold, sel, setSel, pick, selectNeighborhood, label, reload }}>
      {children}
    </Ctx.Provider>
  );
}
