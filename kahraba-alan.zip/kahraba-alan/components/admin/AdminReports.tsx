'use client';
import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { errorMessage } from '@/lib/errors';
import { fmtDateTime, fmtPhone } from '@/lib/format';
import type { ReportState } from '@/lib/types';
import { useLocations } from '../LocationProvider';

type Filter = ReportState | 'all';
const FILTERS: { id: Filter; label: string }[] = [
  { id: 'pending', label: 'قيد التأكيد' }, { id: 'suspicious', label: 'مشبوهة' },
  { id: 'verified', label: 'مؤكدة' }, { id: 'rejected', label: 'مرفوضة' }, { id: 'all', label: 'الكل' },
];
const STATE_C: Record<ReportState, string> = {
  verified: 'bg-on-soft text-on-deep', pending: 'bg-warn-soft text-warn',
  suspicious: 'bg-warn-soft text-warn', rejected: 'bg-off-soft text-off-deep',
};
const STATE_T: Record<ReportState, string> = { verified: 'مؤكد', pending: 'قيد التأكيد', suspicious: 'مشبوه', rejected: 'مرفوض' };

interface Row {
  id: string; neighborhood_id: string; status: 'on' | 'off'; state: ReportState; kind: string; created_at: string;
  profiles: { phone: string | null; display_name: string | null } | null;
}

export default function AdminReports() {
  const { label } = useLocations();
  const [filter, setFilter] = useState<Filter>('pending');
  const [rows, setRows] = useState<Row[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    let q = supabase.from('reports').select('*, profiles(phone, display_name)').order('created_at', { ascending: false }).limit(200);
    if (filter !== 'all') q = q.eq('state', filter);
    const { data } = await q;
    setRows((data ?? []) as unknown as Row[]);
  }, [filter]);
  useEffect(() => { load(); }, [load]);

  async function review(id: string, state: ReportState) {
    setBusy(id); setErr('');
    const { error } = await supabase.rpc('admin_review_report', { p_report: id, p_state: state, p_note: null });
    setBusy(null);
    if (error) setErr(errorMessage(error)); else load();
  }

  return (
    <div>
      <div className="flex flex-wrap gap-1.5">
        {FILTERS.map((f) => (
          <button key={f.id} onClick={() => setFilter(f.id)}
            className={`rounded-lg px-3 py-1.5 text-sm font-bold ${filter === f.id ? 'bg-ink text-white' : 'bg-mist text-muted'}`}>{f.label}</button>
        ))}
      </div>
      {err && <p role="alert" className="mt-3 text-sm font-bold text-off-deep">{err}</p>}
      {rows.length === 0 ? <p className="mt-4 text-sm text-muted">لا توجد بلاغات في هذا القسم.</p> : (
        <ul className="mt-3 divide-y divide-line">
          {rows.map((r) => (
            <li key={r.id} className="py-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-bold">
                  <span className={r.status === 'on' ? 'text-on-deep' : 'text-off-deep'}>{r.status === 'on' ? 'رجعت' : 'قطعت'}</span>
                  {' · '}{label(r.neighborhood_id)}
                </span>
                <span className={`chip ${STATE_C[r.state]}`}>{STATE_T[r.state]}</span>
              </div>
              <p className="mt-0.5 text-xs text-muted">
                {fmtDateTime(r.created_at)} · {r.kind === 'confirmation' ? 'تأكيد' : 'تغيير'} · <span dir="ltr">{fmtPhone(r.profiles?.phone ?? null)}</span>
              </p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {r.state !== 'verified' && <button disabled={busy === r.id} onClick={() => review(r.id, 'verified')} className="btn-light !min-h-[36px] !px-3 text-sm">اعتماد</button>}
                {r.state !== 'rejected' && <button disabled={busy === r.id} onClick={() => review(r.id, 'rejected')} className="btn-light !min-h-[36px] !px-3 text-sm">رفض</button>}
                {r.state !== 'suspicious' && <button disabled={busy === r.id} onClick={() => review(r.id, 'suspicious')} className="btn-light !min-h-[36px] !px-3 text-sm">تعليم كمشبوه</button>}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
