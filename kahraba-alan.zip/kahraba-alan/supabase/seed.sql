-- Geography only. NO electricity data is seeded — every neighborhood starts as "no verified data".
insert into states(slug, name_ar, sort_order) values ('river-nile', 'ولاية نهر النيل', 1)
on conflict (slug) do nothing;

insert into localities(state_id, slug, name_ar, sort_order)
select s.id, v.slug, v.name_ar, v.ord
from states s,
     (values ('berber','بربر',1), ('atbara','عطبرة',2), ('ad-damer','الدامر',3), ('shendi','شندي',4),
             ('abu-hamad','أبو حمد',5), ('al-matamma','المتمة',6), ('al-buhaira','البحيرة',7)) as v(slug, name_ar, ord)
where s.slug = 'river-nile'
on conflict (state_id, slug) do nothing;

-- One starter area per locality so the app works immediately. Add real neighborhoods from the admin dashboard.
insert into neighborhoods(locality_id, name_ar, sort_order)
select id, 'كل المدينة', 0 from localities
on conflict (locality_id, name_ar) do nothing;

insert into neighborhood_live(neighborhood_id)
select id from neighborhoods on conflict do nothing;
