import './globals.css';
import type { Metadata, Viewport } from 'next';
import { Cairo, Tajawal } from 'next/font/google';
import Providers from '@/components/Providers';
import Header from '@/components/Header';

const cairo = Cairo({ subsets: ['arabic', 'latin'], variable: '--font-cairo', display: 'swap' });
const tajawal = Tajawal({ subsets: ['arabic', 'latin'], weight: ['400', '500', '700', '800'], variable: '--font-tajawal', display: 'swap' });

export const metadata: Metadata = {
  title: 'كهرباء الآن — الكهرباء في منطقتك.. لحظة بلحظة',
  description: 'تابع حالة الكهرباء في أحياء ولاية نهر النيل وبلّغ عن القطع والعودة، مع إحصائيات ساعات التشغيل والانقطاع.',
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#13211a' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={`${cairo.variable} ${tajawal.variable}`}>
      <body className="min-h-screen font-body">
        <Providers>
          <Header />
          <main className="mx-auto max-w-6xl px-4 pb-24 pt-5 sm:pb-10">{children}</main>
          <footer className="mx-auto hidden max-w-6xl px-4 pb-8 text-center text-xs text-muted sm:block">
            كهرباء الآن — الكهرباء في منطقتك.. لحظة بلحظة. البيانات من بلاغات المواطنين وليست مصدراً رسمياً.
          </footer>
        </Providers>
      </body>
    </html>
  );
}
