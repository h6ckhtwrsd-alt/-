const MAP: Record<string, string> = {
  AUTH_REQUIRED: 'سجّل الدخول أولاً للإبلاغ.',
  BANNED: 'تم إيقاف حسابك عن الإبلاغ.',
  COOLDOWN: 'أرسلت بلاغاً لهذا الحي قبل قليل. انتظر بضع دقائق قبل بلاغ جديد.',
  DAILY_CAP: 'وصلت للحد اليومي من البلاغات. حاول غداً.',
  DUPLICATE: 'بلاغك بنفس الحالة مسجّل مسبقاً.',
  INVALID_NEIGHBORHOOD: 'الحي المحدد غير متاح.',
  INVALID_STATUS: 'حالة غير صحيحة.',
  INVALID_TIME: 'الوقت غير صالح لهذا الحي.',
  NO_CHANGE: 'الحالة الحالية مطابقة لما أدخلته.',
  FORBIDDEN: 'ليست لديك صلاحية لهذا الإجراء.',
  NOT_FOUND: 'العنصر غير موجود.',
};

export function errorMessage(e: { message?: string } | null | undefined): string {
  const m = e?.message ?? '';
  for (const k of Object.keys(MAP)) if (m.includes(k)) return MAP[k];
  return 'حدث خطأ غير متوقع. تحقق من الاتصال وحاول مرة أخرى.';
}
