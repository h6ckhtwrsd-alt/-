'use client';
import { useRouter } from 'next/navigation';
import { FormEvent, useEffect, useRef, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { normalizeSudanPhone } from '@/lib/format';
import { useAuth } from '@/components/AuthProvider';

export default function Login() {
  const router = useRouter();
  const { session, profile, loading } = useAuth();
  const [step, setStep] = useState<'phone' | 'code'>('phone');
  const [phoneInput, setPhoneInput] = useState('');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [hp, setHp] = useState(''); // honeypot: real users never fill this
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [wait, setWait] = useState(0);
  const lastSend = useRef(0);

  useEffect(() => {
    if (!loading && session && profile) router.replace(profile.default_neighborhood_id ? '/' : '/profile');
  }, [loading, session, profile, router]);

  useEffect(() => {
    if (wait <= 0) return;
    const t = setTimeout(() => setWait((w) => w - 1), 1000);
    return () => clearTimeout(t);
  }, [wait]);

  async function sendCode(e?: FormEvent) {
    e?.preventDefault();
    setErr('');
    if (hp) return; // bot
    if (Date.now() - lastSend.current < 60_000) { setErr('انتظر قليلاً قبل طلب رمز جديد.'); return; }
    const p = normalizeSudanPhone(phoneInput);
    if (!p) { setErr('رقم الهاتف غير صحيح. مثال: 0912345678'); return; }
    setBusy(true);
    const { error } = await supabase.auth.signInWithOtp({ phone: p });
    setBusy(false);
    if (error) {
      setErr(error.status === 429 ? 'طلبات كثيرة. حاول بعد قليل.' : 'تعذّر إرسال الرمز. تحقق من الرقم وحاول مرة أخرى.');
      return;
    }
    lastSend.current = Date.now();
    setPhone(p); setStep('code'); setWait(60);
  }

  async function verify(e: FormEvent) {
    e.preventDefault();
    setErr('');
    const token = code.replace(/[٠-٩]/g, (c) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(c))).replace(/\D/g, '');
    if (token.length < 6) { setErr('أدخل الرمز المكوّن من 6 أرقام.'); return; }
    setBusy(true);
    const { error } = await supabase.auth.verifyOtp({ phone, token, type: 'sms' });
    setBusy(false);
    if (error) setErr('الرمز غير صحيح أو انتهت صلاحيته.');
  }

  return (
    <div className="mx-auto max-w-md">
      <div className="card p-6">
        <h1 className="font-display text-2xl font-extrabold">{step === 'phone' ? 'تسجيل الدخول' : 'أدخل رمز التحقق'}</h1>
        <p className="mt-1 text-sm text-muted">
          {step === 'phone' ? 'ندخلك برقم هاتفك فقط، بدون كلمة مرور. الرقم يُستخدم لمنع البلاغات المزيّفة ولا يظهر للآخرين.'
            : `أرسلنا رمزاً من 6 أرقام إلى ${phone}`}
        </p>

        {step === 'phone' ? (
          <form onSubmit={sendCode} className="mt-5 space-y-4">
            <div>
              <label htmlFor="phone" className="mb-1 block text-sm font-bold text-muted">رقم الهاتف</label>
              <input id="phone" dir="ltr" inputMode="tel" autoComplete="tel" className="input text-start"
                placeholder="09xx xxx xxx" value={phoneInput} onChange={(e) => setPhoneInput(e.target.value)} />
            </div>
            <input tabIndex={-1} autoComplete="off" aria-hidden className="absolute -left-[9999px] h-0 w-0 opacity-0"
              name="website" value={hp} onChange={(e) => setHp(e.target.value)} />
            {err && <p role="alert" className="text-sm font-bold text-off-deep">{err}</p>}
            <button className="btn-dark w-full" disabled={busy}>{busy ? 'جارٍ الإرسال…' : 'إرسال رمز التحقق'}</button>
          </form>
        ) : (
          <form onSubmit={verify} className="mt-5 space-y-4">
            <div>
              <label htmlFor="otp" className="mb-1 block text-sm font-bold text-muted">رمز التحقق</label>
              <input id="otp" dir="ltr" inputMode="numeric" autoComplete="one-time-code" maxLength={8}
                className="input text-center text-2xl tracking-[0.4em]" value={code} onChange={(e) => setCode(e.target.value)} autoFocus />
            </div>
            {err && <p role="alert" className="text-sm font-bold text-off-deep">{err}</p>}
            <button className="btn-dark w-full" disabled={busy}>{busy ? 'جارٍ التحقق…' : 'تأكيد ودخول'}</button>
            <div className="flex items-center justify-between text-sm">
              <button type="button" className="font-bold underline disabled:no-underline disabled:opacity-50" disabled={wait > 0 || busy} onClick={() => sendCode()}>
                {wait > 0 ? `إعادة الإرسال بعد ${wait} ث` : 'إعادة إرسال الرمز'}
              </button>
              <button type="button" className="text-muted underline" onClick={() => { setStep('phone'); setCode(''); setErr(''); }}>تغيير الرقم</button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
