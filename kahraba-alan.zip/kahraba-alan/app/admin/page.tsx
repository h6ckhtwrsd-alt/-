'use client';
import Link from 'next/link';
import { useState } from 'react';
import { useAuth } from '@/components/AuthProvider';
import AdminOverview from '@/components/admin/AdminOverview';
import AdminReports from '@/components/admin/AdminReports';
import AdminLocations from '@/components/admin/AdminLocations';
import AdminUsers from '@/components/admin/AdminUsers';

type Tab = 'overview' | 'reports' | 'locations' | 'users';

export default function Admin() {
  const { session, loading, isStaff, isAdmin } = useAuth();
  const [tab, setTab] = useState<Tab>('overview');

  if (loading) return <p className="text-center text-muted">جارٍ التحميل…</p>;
  if (!session || !isStaff) {
    return (
      <div className="card mx-auto max-w-md p-6 text-center">
        <h1 className="font-display text-xl font-extrabold">هذه الصفحة للمشرفين فقط</h1>
        <p className="mt-2 text-sm text-muted">{session ? 'حسابك لا يملك صلاحية الإدارة.' : 'سجّل الدخول بحساب مشرف للمتابعة.'}</p>
        <Link href={session ? '/' : '/login'} className="btn-dark mt-4">{session ? 'العودة للرئيسية' : 'تسجيل الدخول'}</Link>
      </div>
    );
  }

  const tabs: { id: Tab; label: string; admin?: boolean }[] = [
    { id: 'overview', label: 'نظرة عامة' }, { id: 'reports', label: 'البلاغات' },
    { id: 'locations', label: 'المواقع', admin: true }, { id: 'users', label: 'المستخدمون', admin: true },
  ];

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-extrabold">لوحة الإدارة</h1>
      <div role="tablist" className="flex gap-1.5 overflow-x-auto">
        {tabs.filter((t) => !t.admin || isAdmin).map((t) => (
          <button key={t.id} role="tab" aria-selected={tab === t.id} onClick={() => setTab(t.id)}
            className={`shrink-0 rounded-xl px-4 py-2 text-sm font-bold ${tab === t.id ? 'bg-ink text-white' : 'bg-white text-muted border border-line'}`}>{t.label}</button>
        ))}
      </div>
      <section className="card p-5">
        {tab === 'overview' && <AdminOverview isAdmin={isAdmin} />}
        {tab === 'reports' && <AdminReports />}
        {tab === 'locations' && isAdmin && <AdminLocations />}
        {tab === 'users' && isAdmin && <AdminUsers />}
      </section>
    </div>
  );
}
