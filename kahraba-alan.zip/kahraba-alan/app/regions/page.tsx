'use client';
import { useRouter } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { useLocations } from '@/components/LocationProvider';
import { supabase } from '@/lib/supabase';
import { useNow } from '@/lib/hooks';
import { fmtDuration } from '@/lib/format';
import type { NeighborhoodLive } from '@/lib/types';

type StatusFilter = 'all' | 'on' | 'off' | 'unknown';

export default function Regions() {
  const router = useRouter();
  const { localities, neighborhoods, selectNeighborhood, ready } = useLocations();
  const [live, setLive] = useState<Record<string, NeighborhoodLive>>({});
  const [loc, setLoc] = useState('');
  const [nbId, setNbId] = useState('');
  const [status, setStatus] = useState<StatusFilter>('all');
  const now = useNow();

  useEffect(() => {
    let active = true;
    const load = async () => {
      const { data } = await supabase.from('neighborhood_live').select('*');
      if (active) setLive(Object.fromEntries(((data ?? []) as NeighborhoodLive[]).map((r) => [r.neighborhood_id, r])));
    };
    load();
    const ch = supabase.channel('live-all')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'neighborhood_live' }, (p) => {
        const row = p.new as NeighborhoodLive;
        if (row?.neighborhood_id) setLive((cur) => ({ ...cur, [row.neighborhood_id]: row }));
      }).subscribe();
    return () => { active = false; supabase.removeChannel(ch); };
  }, []);

  const statusOf = (id: string): 'on' | 'off' | 'unknown' => live[id]?.status ?? 'unknown';

  const visible = useMemo(() => neighborhoods.filter((n) => {
    if (loc && n.locality_id !== loc) return false;
    if (nbId && n.id !== nbId) return false;
    if (status !== 'all' && statusOf(n.id) !== status) return false;
    return true;
  }), [neighborhoods, loc, nbId, status, live]); // eslint-disable-line react-hooks/exhaustive-deps

  const count = (s: 'on' | 'off' | 'unknown') => neighborhoods.filter((n) => statusOf(n.id) === s).length;
  const nbOptions = neighborhoods.filter((n) => !loc || n.locality_id === loc);

  const open = (id: string) => { selectNeighborhood(id); router.push('/'); };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-2xl font-extrabold sm:text-3xl">حالة الكهرباء في ولاية نهر النيل</h1>
        <p className="mt-1 text-sm text-muted">تتحدث القائمة لحظياً. الأحياء التي لم يؤكد أحد حالتها تظهر «بلا بيانات».</p>
      </div>

      <dl className="grid grid-cols-3 gap-2.5 text-center">
        <div className="card p-3"><dd className="font-display text-2xl font-extrabold text-on-deep">{count('on')}</dd><dt className="text-xs text-muted">شغالة</dt></div>
        <div className="card p-3"><dd className="font-display text-2xl font-extrabold text-off-deep">{count('off')}</dd><dt className="text-xs text-muted">قاطعة</dt></div>
        <div className="card p-3"><dd className="font-display text-2xl font-extrabold text-muted">{count('unknown')}</dd><dt className="text-xs text-muted">بلا بيانات</dt></div>
      </dl>

      <section className="card grid gap-3 p-4 sm:grid-cols-3" aria-label="التصفية">
        <select className="field" aria-label="المدينة" value={loc} onChange={(e) => { setLoc(e.target.value); setNbId(''); }}>
          <option value="">كل المدن</option>
          {localities.map((l) => <option key={l.id} value={l.id}>{l.name_ar}</option>)}
        </select>
        <select className="field" aria-label="الحي" value={nbId} onChange={(e) => setNbId(e.target.value)}>
          <option value="">كل الأحياء</option>
          {nbOptions.map((n) => <option key={n.id} value={n.id}>{n.name_ar}</option>)}
        </select>
        <select className="field" aria-label="الحالة" value={status} onChange={(e) => setStatus(e.target.value as StatusFilter)}>
          <option value="all">كل الحالات</option>
          <option value="on">شغالة</option>
          <option value="off">قاطعة</option>
          <option value="unknown">بلا بيانات</option>
        </select>
      </section>

      {!ready ? <p className="text-center text-muted">جارٍ التحميل…</p> : (
        localities.map((l) => {
          const items = visible.filter((n) => n.locality_id === l.id);
          if (!items.length) return null;
          return (
            <section key={l.id}>
              <h2 className="mb-2 font-display text-lg font-extrabold">{l.name_ar}</h2>
              <ul className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
                {items.map((n) => {
                  const s = statusOf(n.id);
                  const row = live[n.id];
                  const tone = s === 'on' ? 'border-on/50 bg-on-soft' : s === 'off' ? 'border-off/50 bg-off-soft' : 'border-line bg-white';
                  return (
                    <li key={n.id}>
                      <button onClick={() => open(n.id)} className={`flex w-full items-center gap-3 rounded-2xl border-2 p-3.5 text-start transition hover:shadow-sm ${tone}`}>
                        <span aria-hidden className={`h-4 w-4 shrink-0 rounded-full ${s === 'on' ? 'bg-on' : s === 'off' ? 'bg-off' : 'hatch border border-line'}`} />
                        <span className="min-w-0 flex-1">
                          <span className="block truncate font-bold">{n.name_ar}</span>
                          <span className="block text-xs text-muted">
                            {s === 'unknown' ? 'بلا بيانات مؤكدة' : `${s === 'on' ? 'شغالة' : 'قاطعة'} منذ ${fmtDuration((now - Date.parse(row!.since!)) / 1000)}`}
                          </span>
                        </span>
                        {row && row.pending_count > 0 && <span className="chip bg-warn-soft text-warn">غير مؤكد</span>}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </section>
          );
        })
      )}
      {ready && visible.length === 0 && <p className="card p-6 text-center text-muted">لا توجد أحياء مطابقة للتصفية.</p>}
    </div>
  );
}
