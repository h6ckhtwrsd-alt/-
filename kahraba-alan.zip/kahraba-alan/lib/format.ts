// Sudan has no DST: Africa/Khartoum is a fixed UTC+2.
export const TZ = 'Africa/Khartoum';
export const OFFSET = '+02:00';
export const DAY_MS = 86_400_000;
const LOCALE = 'ar-EG-u-nu-latn'; // Arabic text, Latin digits (clearer on small screens)

export function fmtTime(v: string | number): string {
  return new Intl.DateTimeFormat(LOCALE, { timeZone: TZ, hour: 'numeric', minute: '2-digit', hour12: true }).format(new Date(v));
}
export function fmtDateTime(v: string | number): string {
  return new Intl.DateTimeFormat(LOCALE, {
    timeZone: TZ, day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true,
  }).format(new Date(v));
}
export function fmtDay(key: string): string {
  return new Intl.DateTimeFormat(LOCALE, { timeZone: TZ, weekday: 'long', day: 'numeric', month: 'long' })
    .format(new Date(`${key}T12:00:00${OFFSET}`));
}
export function fmtDayShort(key: string): string {
  return new Intl.DateTimeFormat(LOCALE, { timeZone: TZ, weekday: 'short', day: 'numeric', month: 'numeric' })
    .format(new Date(`${key}T12:00:00${OFFSET}`));
}
export function dayKey(ms: number): string {
  return new Intl.DateTimeFormat('sv-SE', { timeZone: TZ }).format(new Date(ms)); // YYYY-MM-DD
}
export function dayStart(key: string): number {
  return Date.parse(`${key}T00:00:00${OFFSET}`);
}

export function fmtDuration(seconds: number): string {
  const s = Math.max(0, Math.round(seconds));
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (d > 0) return h > 0 ? `${d} يوم و${h} س` : `${d} يوم`;
  if (h > 0) return m > 0 ? `${h} س ${m} د` : `${h} س`;
  if (m > 0) return `${m} د`;
  return 'أقل من دقيقة';
}
export function fmtHours(seconds: number): string {
  return (seconds / 3600).toLocaleString('en-US', { maximumFractionDigits: 1 });
}
export function timeAgo(iso: string | null, now = Date.now()): string {
  if (!iso) return '—';
  const diff = (now - Date.parse(iso)) / 1000;
  if (diff < 60) return 'الآن';
  return `منذ ${fmtDuration(diff)}`;
}

export function fmtPhone(p: string | null): string {
  if (!p) return '—';
  return p.startsWith('+') ? p : `+${p}`;
}

export function normalizeSudanPhone(input: string): string | null {
  let d = input.replace(/[\s\-()]/g, '').replace(/[٠-٩]/g, (c) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(c)));
  if (d.startsWith('00')) d = `+${d.slice(2)}`;
  if (d.startsWith('+')) {
    if (d.startsWith('+249')) return /^\+249\d{9}$/.test(d) ? d : null;
    return /^\+\d{8,15}$/.test(d) ? d : null;
  }
  if (d.startsWith('249')) d = `+${d}`;
  else if (d.startsWith('0')) d = `+249${d.slice(1)}`;
  else d = `+249${d}`;
  return /^\+249\d{9}$/.test(d) ? d : null;
}
