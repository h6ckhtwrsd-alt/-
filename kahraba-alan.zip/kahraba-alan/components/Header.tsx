'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from './AuthProvider';

const NAV = [
  { href: '/', label: 'الرئيسية', icon: '⚡' },
  { href: '/regions', label: 'المناطق', icon: '🗺️' },
];

export default function Header() {
  const { session, profile, isStaff } = useAuth();
  const path = usePathname();
  const items = isStaff ? [...NAV, { href: '/admin', label: 'الإدارة', icon: '🛠️' }] : NAV;
  const active = (href: string) => (href === '/' ? path === '/' : path.startsWith(href));

  return (
    <>
      <header className="sticky top-0 z-30 border-b border-line bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-2.5">
          <Link href="/" className="flex min-w-0 items-center gap-2.5">
            <span aria-hidden className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-ink text-xl text-white">⚡</span>
            <span className="min-w-0 leading-tight">
              <span className="block font-display text-xl font-extrabold">كهرباء الآن</span>
              <span className="block truncate text-[11px] text-muted sm:text-xs">تابع حالة الكهرباء في منطقتك.</span>
            </span>
          </Link>

          <nav className="hidden items-center gap-1 sm:flex" aria-label="التنقل الرئيسي">
            {items.map((i) => (
              <Link key={i.href} href={i.href}
                className={`rounded-lg px-3 py-2 text-sm font-bold ${active(i.href) ? 'bg-ink text-white' : 'text-muted hover:bg-mist'}`}>
                {i.label}
              </Link>
            ))}
          </nav>

          {session ? (
            <Link href="/profile" className="btn-light !min-h-[40px] !px-3 text-sm" aria-label="حسابي">
              <span aria-hidden>👤</span>
              <span className="max-w-[7rem] truncate">{profile?.display_name || 'حسابي'}</span>
            </Link>
          ) : (
            <Link href="/login" className="btn-dark !min-h-[40px] !px-4 text-sm">تسجيل الدخول</Link>
          )}
        </div>
      </header>

      {/* mobile bottom navigation */}
      <nav aria-label="التنقل" className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-white sm:hidden">
        <ul className="mx-auto flex max-w-md">
          {[...items, { href: session ? '/profile' : '/login', label: session ? 'حسابي' : 'دخول', icon: '👤' }].map((i) => (
            <li key={i.href} className="flex-1">
              <Link href={i.href}
                className={`flex min-h-[56px] flex-col items-center justify-center gap-0.5 text-xs font-bold ${active(i.href) ? 'text-on-deep' : 'text-muted'}`}>
                <span aria-hidden className="text-lg">{i.icon}</span>
                {i.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </>
  );
}
