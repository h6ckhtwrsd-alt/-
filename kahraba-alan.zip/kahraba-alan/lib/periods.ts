import type { PowerStatus, StatusEvent } from './types';

export interface Period { status: PowerStatus; start: number; end: number; ongoing: boolean; source: StatusEvent['source']; count: number }

/** Turn verified status-change events into [start,end) periods. The last one runs until `now`. */
export function buildPeriods(events: StatusEvent[], now: number): Period[] {
  const sorted = [...events].sort((a, b) => Date.parse(a.started_at) - Date.parse(b.started_at));
  return sorted.map((e, i) => {
    const next = sorted[i + 1];
    const start = Date.parse(e.started_at);
    const end = next ? Date.parse(next.started_at) : now;
    return { status: e.status, start, end: Math.max(end, start), ongoing: !next, source: e.source, count: e.report_count };
  });
}

export function clipPeriods(periods: Period[], from: number, to: number): Period[] {
  return periods
    .map((p) => ({ ...p, start: Math.max(p.start, from), end: Math.min(p.end, to) }))
    .filter((p) => p.end > p.start);
}
