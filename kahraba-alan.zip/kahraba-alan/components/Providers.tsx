'use client';
import { ReactNode } from 'react';
import AuthProvider from './AuthProvider';
import LocationProvider from './LocationProvider';

export default function Providers({ children }: { children: ReactNode }) {
  return (
    <AuthProvider>
      <LocationProvider>{children}</LocationProvider>
    </AuthProvider>
  );
}
