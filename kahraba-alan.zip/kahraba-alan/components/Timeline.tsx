'use client';
import { useMemo, useState } from 'react';
import { DAY_MS, dayKey, dayStart, fmtDay, fmtDuration, fmtTime } from '@/lib/format';
import { buildPeriods, type Period } from '@/lib/periods';
import type { StatusEvent } from '@/lib/types';
import DayStrip from './DayStrip';

export default function Timeline({ events, now }: { events: StatusEvent[]; now: number }) {
  const [shown, setShown] = useState(5);

  const groups = useMemo(() => {
    const periods = buildPeriods(events, now);
    const map = new Map<string, Period[]>();
    const minKey = dayKey(dayStart(dayKey(now)) - 13 * DAY_MS);
    for (const p of periods) {
      const k = dayKey(p.start);
      if (k < minKey) continue; // the older event only gives the first day its starting state
      map.set(k, [...(map.get(k) ?? []), p]);
    }
    return { periods, days: [...map.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1)) };
  }, [events, now]);

  return (
    <section className="card p-5">
      <h2 className="font-display text-lg font-extrabold">سجل الكهرباء</h2>
      <p className="text-sm text-muted">كل تغيّر مؤكد في آخر 14 يوماً، ومدة كل فترة.</p>

      {groups.days.length === 0 ? (
        <p className="mt-4 rounded-xl bg-mist p-4 text-sm text-muted">لا توجد تغيّرات مؤكدة مسجّلة بعد لهذا الحي.</p>
      ) : (
        <div className="mt-4 space-y-6">
          {groups.days.slice(0, shown).map(([day, list]) => (
            <div key={day}>
              <h3 className="mb-2 text-sm font-extrabold">{fmtDay(day)}</h3>
              <DayStrip periods={groups.periods} day={day} now={now} ticks={false} height="h-3.5" />
              <ol className="mt-3 space-y-0 border-s-2 border-line ps-4">
                {[...list].reverse().map((p) => (
                  <li key={p.start} className="relative pb-4 last:pb-0">
                    <span className={`absolute -start-[1.4rem] top-1 h-3 w-3 rounded-full border-2 border-white ${p.status === 'on' ? 'bg-on' : 'bg-off'}`} />
                    <div className="flex flex-wrap items-baseline justify-between gap-x-3">
                      <span className={`font-bold ${p.status === 'on' ? 'text-on-deep' : 'text-off-deep'}`}>
                        {p.status === 'on' ? 'رجعت الكهرباء' : 'قطعت الكهرباء'} · {fmtTime(p.start)}
                      </span>
                      <span className="text-sm text-muted">
                        {p.ongoing ? `مستمرة منذ ${fmtDuration((p.end - p.start) / 1000)}` : `استمرت ${fmtDuration((p.end - p.start) / 1000)}`}
                      </span>
                    </div>
                    <p className="text-xs text-muted">
                      {p.source === 'citizen' ? `أكّدها ${p.count} مستخدم` : 'سجّلها مشرف'}
                    </p>
                  </li>
                ))}
              </ol>
            </div>
          ))}
          {groups.days.length > shown && (
            <button className="btn-light w-full" onClick={() => setShown((s) => s + 5)}>عرض أيام أقدم</button>
          )}
        </div>
      )}
    </section>
  );
}
