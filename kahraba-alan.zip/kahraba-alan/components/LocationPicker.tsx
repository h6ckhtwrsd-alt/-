'use client';
import type { Sel } from '@/lib/types';
import { useLocations } from './LocationProvider';

export default function LocationPicker({ value, onChange }: { value: Sel; onChange: (s: Sel) => void }) {
  const { states, localities, neighborhoods, pick, ready } = useLocations();
  const locs = localities.filter((l) => l.state_id === value.stateId);
  const nbs = neighborhoods.filter((n) => n.locality_id === value.localityId);

  const Label = ({ id, children }: { id: string; children: string }) => (
    <label htmlFor={id} className="mb-1 block text-sm font-bold text-muted">{children}</label>
  );

  return (
    <div className="grid gap-3 sm:grid-cols-3">
      <div>
        <Label id="pick-state">الولاية</Label>
        <select id="pick-state" className="field" disabled={!ready} value={value.stateId ?? ''}
          onChange={(e) => onChange(pick('state', e.target.value, value))}>
          {states.map((s) => <option key={s.id} value={s.id}>{s.name_ar}</option>)}
        </select>
      </div>
      <div>
        <Label id="pick-locality">المدينة / المحلية</Label>
        <select id="pick-locality" className="field" disabled={!ready || !locs.length} value={value.localityId ?? ''}
          onChange={(e) => onChange(pick('locality', e.target.value, value))}>
          {locs.map((l) => <option key={l.id} value={l.id}>{l.name_ar}</option>)}
        </select>
      </div>
      <div>
        <Label id="pick-nb">الحي</Label>
        <select id="pick-nb" className="field" disabled={!ready || !nbs.length} value={value.neighborhoodId ?? ''}
          onChange={(e) => onChange(pick('neighborhood', e.target.value, value))}>
          {nbs.map((n) => <option key={n.id} value={n.id}>{n.name_ar}</option>)}
        </select>
      </div>
    </div>
  );
}
